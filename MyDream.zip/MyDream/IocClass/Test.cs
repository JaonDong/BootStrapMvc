﻿namespace IocClass
{
    public class Test
    {
         
    }
}